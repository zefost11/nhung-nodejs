var express = require('express');
var r= express.Router();
var User = require('../models/User');
var Category = require('../models/Category');
var Device = require('../models/Device');
var Permission = require('../models/Permission');
var DeviceStatus = require('../models/DeviceStatus');

r.get('/add', function(req, res, next) {
  
	res.render('add_category');

});

r.post('/add',function(req,res){
	var name = req.body.name;
	var description = req.body.description;

	var c = new Category({
		name: name,
		description: description
	});

	c.save(function(err){
		if(!err){
			res.send("Đã thêm Danh Mục!");
		}
		else{
			res.send("Lỗi :"+err);
		}
	});
});

module.exports = r;
