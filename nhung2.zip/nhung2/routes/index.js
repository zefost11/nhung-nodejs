var express = require('express');
var r= express.Router();
var User = require('../models/User');
var Category = require('../models/Category');
var Device = require('../models/Device');
var Permission = require('../models/Permission');
var DeviceStatus = require('../models/DeviceStatus');
var Log = require('../models/Log');

r.get('/', function(req, res, next) {
  		var username = req.session.logined;
						//Find User
					var u = User.findOne({username: username},function(er, u){
							if(!er){
								var cat = Category.find({},function(e, cat){
									if(!e){

										var d = Device.find({}, function(loi, d){
											if(!loi){

												var p = Permission.find({userId: u._id},function(lo, p){
														if(!lo){

															req.session.logined = u.username;	

															res.render("index",{user: u, categories: cat, devices: d, permissions: p});
														}
												});

											}
										});

									}
								});
							}
					});

});

r.get('/login',function(req,res){
	if(req.session.logined != undefined){
		res.redirect('/');
	}
	else{
		res.render('login');
	}
});

r.get('/permission', function(req,res){

	var u = User.find({}, function(err,u){
		if(!err){
			var p = Permission.find({}, function(er, p){
				if(!er){
					var d = Device.find({}, function(e, d){
						if(!e){
							res.render('list_user', {users: u, permission: p, devices: d});
						}
					});
				}
			});
		}
	});

});

r.get('/log', function(req, res){
	var l = Log.find({}, function(err, l){
		if(!err){
			res.render('log',{logs:l});
		}
		else{
			res.send("Loi in log");
		}
	});
});

r.post('/login', function(req,res){
	var username = req.body.username;
	var password = req.body.password;

	var c = User.count({username: username, password: password},function(err, c){
			if(!err){
				if( c == 1){
					//Find User
					var u = User.findOne({username: username, password: password},function(er, u){
							if(!er){
								var cat = Category.find({},function(e, cat){
									if(!e){

										var d = Device.find({}, function(loi, d){
											if(!loi){

												var p = Permission.find({userId: u._id},function(lo, p){
														if(!lo){

															req.session.logined = u.username;	

															res.render("index",{user: u, categories: cat, devices: d, permissions: p});
														}
												});

											}
										});

									}
								});
							}
					});
				}
			}
	});
});

module.exports = r;
