var express = require('express');
var r= express.Router();
var User = require('../models/User');
var Category = require('../models/Category');
var Device = require('../models/Device');
var Permission = require('../models/Permission');
var DeviceStatus = require('../models/DeviceStatus');

r.get('/add', function(req, res, next) {
 
	var c = Category.find({},function(err,c){
		if(!err){
			res.render('add_device',{categories: c});
		}
		else{
			res.send("Loi, vui long thu lai!");
		}
	});

});


r.get('/check/:id',function(req,res){

	var id = req.params.id;

	var s = DeviceStatus.findOne({deviceId: id},function(err, s){
		if(!err){
			var status = s.isOn;
			if(status == true){
				res.send("ON");
			}
			else{
				res.send("OFF");
			}
		}
	});
});

r.post('/add', function(req,res){
	var name = req.body.name;
	var id = req.body.id;
	var category = req.body.category;

	var d = new Device({
		name: name,
		id: id,
		category: category
	});

	d.save(function(err){
		if(!err){
			
			var dv = new DeviceStatus({
					deviceId: id,
					isOn: false
				});

				dv.save(function(er){
					if(!er){

						res.send("Da them thiet bi thanh cong!");
					}
				});
		}
		else{
			res.send("That bai! Vui long thu lai!"+err);
		}
	});
});

module.exports = r;
