var express = require('express');
var r= express.Router();
var User = require('../models/User');
var Category = require('../models/Category');
var Device = require('../models/Device');
var Permission = require('../models/Permission');
var DeviceStatus = require('../models/DeviceStatus');

r.get('/user/:username/:password/:name/:level', function(req, res, next) {

	var username = req.params.username;
	var password = req.params.password;
	var name = req.params.name;
	var level = req.params.level;
		level = parseInt(level);

  	var u = new User({
  		username: username,
  		password: password,
  		name: name,
  		level: level
  	});

  	u.save(function(err){
  		if(!err){
  			res.send("Đã thêm User");
  		}
  		else{
  			res.send("Lỗi: "+ err);
  		}
  	});
});

r.get('/device/:name/:id/:category',function(req,res){

		var name = req.params.name;
		var id = req.params.id;
		var category = req.params.category;

		var d = new Device({
			name: name,
			id: id,
			category: category
		});

		d.save(function(err){
			if(!err){

				var dv = new DeviceStatus({
					deviceId: id,
					isOn: false
				});

				dv.save(function(er){
					if(!er){

						res.send("Da them thiet bi thanh cong!");
					}
				});

				
			}
			else{
				res.send("Loi : "+err);
			}
		});

});

r.get('/category/:name/:description',function(req,res){

		var name = req.params.name;
		var description = req.params.description;

		var c = new Category({
			name: name,
			description: description
		});

		c.save(function(err){
			if(!err){
				res.send("Da them Danh muc thanh cong!");
			}
			else{
				res.send("Loi: "+err);
			}
		});
});


module.exports = r;
