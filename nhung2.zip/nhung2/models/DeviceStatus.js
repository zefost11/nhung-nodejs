var mongoose = require('mongoose');

var deviceStatusSchema = mongoose.Schema({
	deviceId: {
		type: String
	},
	isOn:{
		type: Boolean
	}
});

var DeviceStatus = module.exports = mongoose.model('deviceStatus', deviceStatusSchema);


// Fetch Single device
module.exports.getDeviceStatusById = function(id, callback){
	deviceStatus.findOne({deviceId: id}, callback);
}
