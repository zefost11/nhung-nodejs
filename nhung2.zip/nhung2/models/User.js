var mongoose = require('mongoose');

var userSchema = mongoose.Schema({
	username: {
		type: String
	},
	name: {
		type: String
	},

	password: {
		type: String
	},
	level: {
		type: Number
	}
});

var User = module.exports = mongoose.model('user', userSchema);

// Fetch All user
module.exports.getUserByUsername = function(username, callback, limit){
	var query = {username: username};
	User.findOne(query,callback);
}

// Fetch Single user
module.exports.getUserById = function(id, callback){
	User.findById(id, callback);
}
