var mongoose = require('mongoose');

var categorySchema = mongoose.Schema({
	name: {
		type: String
	},
	description :{
		type: String
	}
});

var Category = module.exports = mongoose.model('category', categorySchema);


// Fetch Single Category
module.exports.getCategoryByName = function(name, callback){
	Category.find({name: name}, callback);
}
