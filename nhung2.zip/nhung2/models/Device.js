var mongoose = require('mongoose');

var deviceSchema = mongoose.Schema({
	name: {
		type: String
	},
	id: {
		type: String
	},
	category: {
		type: String
	}
});

var Device = module.exports = mongoose.model('device', deviceSchema);


// Fetch Single device
module.exports.getDeviceById = function(id, callback){
	device.findOne({id: id}, callback);
}
