var mongoose = require('mongoose');

var permissionSchema = mongoose.Schema({
	userId: {
		type: String
	},
	deviceId: {
		type: String
	}
});

var Permission = module.exports = mongoose.model('permission', permissionSchema);


// Fetch Single permission
module.exports.getPermissionByUsername = function(username, callback){
	Permission.find({name: name}, callback);
}
