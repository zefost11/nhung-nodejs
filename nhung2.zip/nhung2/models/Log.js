var mongoose = require('mongoose');

var logSchema = mongoose.Schema({
	name: {
		type: String
	},
	username: {
		type: String
	},
	action: {
		type: String
	},
	device: {
		type: String
	},
	time: {
		type: String
	}
});

var Log = module.exports = mongoose.model('log', logSchema);


// Fetch Single device
module.exports.getLogs = function(callback){
	Log.find({}, callback);
}
